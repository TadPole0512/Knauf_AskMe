package com.limenets.eorder.svc;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.inject.Inject;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.limenets.common.exception.MsgCode;
import com.limenets.common.util.Converter;
import com.limenets.eorder.dao.WeatherDao;
import com.limenets.eorder.dto.WeatherDto;
import com.limenets.eorder.util.GeoTransUtil;
import com.limenets.eorder.util.WeatherMidLandResponseXml;
import com.limenets.eorder.util.WeatherMidTaResponseXml;
import com.limenets.eorder.util.WeatherShortResponseXml;
import com.limenets.eorder.util.WeatherShortSummaryByHalfDay;

/**
 * 날씨 예보 서비스.
 */
@Service
public class WeatherSvc {
	private static final Logger logger = LoggerFactory.getLogger(WeatherSvc.class);
	
	@Value("${kakao.local.api.key}")     private String kakaoApiKey;
	@Value("${kakao.local.api.url}")     private String kakaoApiUrl;
	@Value("${weather.api.en.key}")      private String weatherApiEnKey; //인코딩 키. 기상청에서 인코딩, 디코딩키 둘 다 제공. 디코딩을 인코딩해서 사용하면 오류 발생해서 그냥 인코딩 버전을 사용.
	@Value("${weather.api.de.key}")      private String weatherApiDeKey; //디코딩 키. 기상청측에서도 api환경, 호출 조건에 따라 적용되는 방식이 다르다며 둘 중 구동되는 키를 사용하라고 함.
	@Value("${weather.api.short.url}")   private String weatherApiShortUrl;
	@Value("${weather.api.midta.url}")   private String weatherApiMidTaUrl;
	@Value("${weather.api.midland.url}") private String weatherApiMidLandUrl;
	
	
	@Inject private WeatherDao weatherDao;
	
	
	//로컬에서 카카오 api 사용시 인증서 관련 오류 발생. 테스트 환경에서만 사용해야 함. 보안에 취약.
	private static void disableSslVerification() throws Exception {
		TrustManager[] trustAllCerts = new TrustManager[]{
			new X509TrustManager() {
				public X509Certificate[] getAcceptedIssuers() { return null; }
				public void checkClientTrusted(X509Certificate[] certs, String authType) { }
				public void checkServerTrusted(X509Certificate[] certs, String authType) { }
			}
		};

		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		HostnameVerifier allHostsValid = (hostname, session) -> true;
		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	}
	
	/**
	 * 납품처의 주소 정보로 해당 지역의 날씨 정보를 기상청 API로 조회
	 * @작성일 : 2025. 6. 12
	 * @작성자 : ijy
	 */
	public Map<String, Object> getWeatherForecastApiAjax(Map<String, Object> params) throws Exception {
		
		try {
			disableSslVerification(); //로컬 테스트용.
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		Map<String, Object> svcMap = new HashMap<>();
		Map<String, Object> msgMap = new HashMap<>();
		
		String forecastType = Converter.toStr(params.get("forecastType")); //1:납품일자 선택 시, 2:상단 D+7

		if("1".equals(forecastType)) {
			
			String addr = Converter.toStr(params.get("addr")).trim(); //납품처 주소
			String selDate = Converter.toStr(params.get("selDate")).trim(); //선택날짜
			
			if("".equals(addr) || "".equals(selDate) || "".equals(forecastType)) {
				return MsgCode.getResultMap(MsgCode.DATA_REQUIRE_ERROR2);
			}
			
			svcMap.put("addr",  addr);
			
			//선택 날짜가 오늘부터 3일 이내인지 4~10일인지 체크. 11일 이상은 기상청 API에서 서비스 제공 안함.
			String toDate = Converter.dateToStr("yyyyMMdd");
			selDate  = Converter.convertDateFormat(selDate, "yyyyMMdd");
			int diff = Converter.dateDiff(toDate, selDate, "D");
//			//logger.debug("diff : " + diff);
			
			//api 종류 (1~3일 단기예보, 4~10일 중기예보) > 기상청 API는 주소나 우편번호를 쓰지 않고 좌표값이나 기상청에서 정의한 구역 코드를 이용해서 호출해야 함. 자세한 설명은 아래에..
			if(diff > 3) {
				//3일 넘어가면 중기예보 사용.
				//중기예보: 4~10일까지 일별로 오전, 오후 요약 날씨 조회 가능. (8,9,10일 날씨는 오전,오후 구분 없이 하루 요약 정보만 조회 가능)
				//중기에보는 중기기온예보와 중기육상예보 2가지로 구분.
				//중기기온예보는 최저/최고 기온 조회, 중기육상예보는 맑음,흐림 등 날씨 정보 / 비,눈,비없음 등 강수여부 정보 / 강수확률 정보.
				//중기예보 API는 기상청에서 미리 정의한 중기기온예보구역코드와 중기육상예보구역코드를 활용해서 호출해야 함. (같은 중기예보구역코든데 코드값이 또 달라..)
				
				//주소 정보로 각 예보구역코드 조회
				String midTaAreaCd   = getWeatherAreaCd(addr, "ta");   //중기기온예보
				String midLandAreaCd = getWeatherAreaCd(addr, "land"); //중기육상예보
				
//				//logger.debug("midTaAreaCd = " + midTaAreaCd);
//				//logger.debug("midLandAreaCd = " + midLandAreaCd);
				
				//예보구역코드로 중기 예보 API호출.
				///ijy
				String tmFc = toDate+"0600"; //중기예보 6시 발표. 0600은 그냥 고정.
				Map<String, Object> midTaItem   = getWeatherMidTaApi(tmFc, midTaAreaCd);
				Map<String, Object> midLandItem = getWeatherMidLandApi(tmFc, midLandAreaCd);
				
				
				//2종의 응답값을 하나로 묶어서 리턴.
				List<Map<String, Object>> weatherList = new ArrayList<>();
				List<Map<String, Object>> midList = summarizeMidForecast(midTaItem, midLandItem);  //이게 통합이 될거라 생각했는데 안됨...
				
				//조회된 날씨 정보 목록 중 원하는 날짜의 데이터만 추출.
				if(midList != null && midList.size() > 0) {
					for(Map<String, Object> oneDay : midList ) {
						if(selDate.equals(oneDay.get("date"))) {
							weatherList.add(oneDay);
						}
					}
				}
				
				msgMap.put("weatherList", weatherList);
				
			} else {
				//3일 이내는 단기예보 사용.
				//단기예보: 1~5일까지 1시간 단위로 날씨 조회 가능(5일차 데이터는 1~4일 데이터와 다르게 요약 날씨인듯, 데이터 불량. 어차피 1~3일만 사용 예정.)
				//단기예보 API는 위/경도 값을 기상청API에서 사용하는 격자값으로 변환 후 호출해야 함.
				
				//주소 정보를 카카오 로컬 API를 통해 위/경도 조회 후 격자값으로 변환.
				Map<String, Object> kakaoMap = getKakaoLocalApi(addr);
				String nx = Converter.toStr(kakaoMap.get("nx"));
				String ny = Converter.toStr(kakaoMap.get("ny"));
				
				//단기예보 API호출. 날짜 형식은 yyyyMMdd로 해야 됨.
				msgMap = getWeatherShortApi(toDate, nx, ny); //1일~4일. (5일 데이터는 의미 없음. 데이터 이상함)
				
				List<Map<String, Object>> weatherList = new ArrayList<>();
				List<Map<String, Object>> shortList   = (List<Map<String, Object>>) msgMap.get("shortList");
				
				//조회된 날씨 정보 목록 중 원하는 날짜의 데이터만 추출.
				if(shortList != null && shortList.size() > 0) {
					for(Map<String, Object> oneDay : shortList ) {
						if(selDate.equals(oneDay.get("date"))) {
							weatherList.add(oneDay);
						}
					}
				}
				msgMap.put("weatherList", weatherList);
				msgMap.remove("shortList");
				
			}
			
			
			
		} else {
			//상단 D+7은 단기와 중기 모두 사용해서 하나로 합쳐서 뿌려줘야 함. 1~3일은 단기, 4~10일은 중기. 단기예보의 형식으로 통합하면 될듯.
			List<Map<String, Object>> weatherList = new ArrayList<>();


			/* **************** 주요시도 목록 ******************** */
			/* 1. 주요 시도 배열 */
			//String[] cities = { "서울", "부산", "대구", "인천", "광주", "대전", "울산", "세종", "수원", "춘천", "청주", "천안", "전주", "여수", "포항", "창원", "제주" };
			String[] cities = { "서울", "부산", "대구", "인천", "광주", "대전", "울산", "세종" };

			/* 2. 오늘 날짜 구하기 */
			String toDate = Converter.dateToStr("yyyyMMdd");

			//String addr = cities[0];
			/* **************** 3. 주요 시도 반복 ******************** */
			for(String addr : cities) {
				/* **************** 3-1. 주요 시도 좌표(KakaoLocalAPi) 구하기 ******************** */
				//1~3일. 주소 정보를 카카오 로컬 API를 통해 위/경도 조회 후 격자값으로 변환.
				Map<String, Object> kakaoMap = getKakaoLocalApi(addr);
				String nx = Converter.toStr(kakaoMap.get("nx"));
				String ny = Converter.toStr(kakaoMap.get("ny"));
			
				/* **************** 3-2. 단기예보(1-3일) 구하기 ******************** */
				//단기예보 API호출. 날짜 형식은 yyyyMMdd로 해야 됨.
				msgMap = getWeatherShortApi(toDate, nx, ny); //1일~4일. (5일 데이터는 의미 없음. 데이터 이상함)
				
				List<Map<String, Object>> shortList   = (List<Map<String, Object>>) msgMap.get("shortList");

				/* **************** 3-3. 주소 정보로 중기기온예보 구역코드 구하기 ******************** */
				//4~10일. 주소 정보로 각 예보구역코드 조회
				String midTaAreaCd   = getWeatherAreaCd(addr, "ta");   //중기기온예보
				/* **************** 3-4. 주소 정보로 중기육상예보 구역코드 구하기 ******************** */
				String midLandAreaCd = getWeatherAreaCd(addr, "land"); //중기육상예보


				//예보구역코드로 중기 예보 API호출.
				String tmFc = toDate+"0600"; //중기예보 6시 발표. 0600은 그냥 고정.

				/* **************** 3-5. 중기기온예보(4-10일) 구하기 ******************** */
				Map<String, Object> midTaItem   = getWeatherMidTaApi(tmFc, midTaAreaCd);
				/* **************** 3-6. 중기육상예보(4-10일) 구하기 ******************** */
				Map<String, Object> midLandItem = getWeatherMidLandApi(tmFc, midLandAreaCd);



				/* **************** 3-7. 중기기온예보와 중기육상예보 합치기 ******************** */
				//2종의 응답값을 하나로 묶어서 리턴.
				List<Map<String, Object>> midList = summarizeMidForecast(midTaItem, midLandItem);  //이게 통합이 될거라 생각했는데 안됨...
				
		
				/* **************** 3-8. 단기 예보와 중기 예보 합치기 ******************** */
				List<Map<String, Object>> mergeList = new ArrayList<>(shortList.subList(0, shortList.size()- 2));
				mergeList.addAll(midList);

				Map<String, Object> tmpMap = new HashMap<>();
				tmpMap.put("city", addr);
				tmpMap.put("cityWeatherList", mergeList);
				weatherList.add(tmpMap);
			}

			msgMap.put("weatherList", weatherList);

		}
		
		
		return msgMap;
	}
	
	
	/**
	 * 카카오 로컬 API. 납품처 주소로 위/경도 조회
	 * @작성일 : 2025. 6.12
	 * @작성자 : ijy
	 */
	public Map<String, Object> getKakaoLocalApi(String addr){
		Map<String, Object> returnMap = new HashMap<>();
		
		String query = UriComponentsBuilder
				.fromHttpUrl(kakaoApiUrl)
				.queryParam("query", addr)
				.build()
				.toUriString();

		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "KakaoAK " + kakaoApiKey); //카카오 api는 키를 헤더에 담아서 보내야함. (기상청은 url에 추가)

		HttpEntity<Void> requestEntity = new HttpEntity<>(headers);
		RestTemplate restTemplate = new RestTemplate();

		ResponseEntity<JsonNode> response = restTemplate.exchange(
				query,
				HttpMethod.GET,
				requestEntity,
				JsonNode.class
		);

		JsonNode documents = response.getBody().path("documents");
		
		//logger.debug("response.getStatusCode = " + response.getStatusCode());
		//logger.debug("response.getHeaders = " + response.getHeaders());
		//logger.debug("response.getBody = " + response.getBody());
		
		int nx = 0;
		int ny = 0;
		
		if (documents.isArray() && documents.size() > 0) {
			JsonNode location = documents.get(0);
			double x = location.path("x").asDouble(); // longitude
			double y = location.path("y").asDouble(); // latitude
			
			//logger.debug("x: " + x + " / y: " + y);
			
			GeoTransUtil.GridPoint point = GeoTransUtil.convertGPS2GRID(x, y);
			
			nx = point.x;
			ny = point.y;
			
			//logger.debug("기상청 격자 X: " + nx);
			//logger.debug("기상청 격자 Y: " + ny);
			
		} else {
			//logger.debug("카카오 API 좌표 조회 실패. " + addr);
		}
		
		returnMap.put("nx", nx);
		returnMap.put("ny", ny);
		return returnMap;
	}
	
	
	/**
	 * 기상청 API 단기예보
	 * @작성일 : 2025. 6. 12
	 * @작성자 : ijy
	 */
	public Map<String, Object> getWeatherShortApi(String base_date, String nx, String ny){
		Map<String, Object> returnMap = new HashMap<>();
		
		try {
			String base_time = "0500"; //단기예보는 05시에 발표. 항상 0500으로 고정값.
			
			StringBuilder urlBuilder = new StringBuilder(weatherApiShortUrl);
			urlBuilder.append("?serviceKey=" + weatherApiEnKey);
			urlBuilder.append("&pageNo=1" );
			urlBuilder.append("&numOfRows=1000" );
			urlBuilder.append("&dataType=XML");
			urlBuilder.append("&base_date="+base_date);
			urlBuilder.append("&base_time="+base_time);
			urlBuilder.append("&nx="+nx);
			urlBuilder.append("&ny="+ny);
			

			URL url = new URL(urlBuilder.toString());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-type", "application/json");

			//logger.debug("Response Code: " + conn.getResponseCode());

			BufferedReader rd;
			if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
				rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			} else {
				rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
			}

			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = rd.readLine()) != null) {
				sb.append(line);
			}

			rd.close();
			conn.disconnect();
			
			String xml = sb.toString();
			//logger.debug(xml);
			
			
			// XML → 객체 변환
			JAXBContext context = JAXBContext.newInstance(WeatherShortResponseXml.class);
			Unmarshaller unmarshaller = context.createUnmarshaller();
			WeatherShortResponseXml response = (WeatherShortResponseXml) unmarshaller.unmarshal(new StringReader(xml));

			// 결과 출력
			//logger.debug("결과 코드: " + response.getHeader().getResultCode());
			//logger.debug("결과 메시지: " + response.getHeader().getResultMsg());
			
			String resultCode = response.getHeader().getResultCode();
			returnMap.put("resultCode", resultCode);
			
			List<Map<String, Object>> list = new ArrayList<>();
			if("00".equals(resultCode)) {
				//단기예보는 1~5일까지 1시간 단위로 날씨 정보를 조회함. 결과값을 요구사항에 맞게 일별 오전/오후 요약날씨로 변환. (5일차 정보는 이상함. 중기예보가 4일부터 제공되니 4일 이상은 중기 사용)
				list = WeatherShortSummaryByHalfDay.summarize(response.getBody().getItems().getItem());
				
				if(list.size() > 0) {
					for (Map<String, Object> weatherMap : list) {
						//logger.debug("weatherMap : " + weatherMap.toString());
					}
					
					returnMap.put("shortList", list);
				}
				
			} else {
				//logger.debug("resultCode 00 X : " + resultCode);
			}

			
			//logger.debug("--------------------------------");

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return returnMap;
	}
	
	
	/**
	 * 기상청 API 중기기온예보
	 * @작성일 : 2025. 6. 12
	 * @작성자 : ijy
	 */
	public Map<String, Object> getWeatherMidTaApi(String tmFc, String regId){
		Map<String, Object> returnMap = new HashMap<>();
		try {
			StringBuilder urlBuilder = new StringBuilder(weatherApiMidTaUrl);
			urlBuilder.append("?serviceKey=" + weatherApiEnKey);
			urlBuilder.append("&pageNo=1" );
			urlBuilder.append("&numOfRows=100" );
			urlBuilder.append("&dataType=XML");
			urlBuilder.append("&regId="+regId);
			urlBuilder.append("&tmFc="+tmFc);
			

			URL url = new URL(urlBuilder.toString());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-type", "application/json");

			//logger.debug("Response Code: " + conn.getResponseCode());

			BufferedReader rd;
			if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
				rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			} else {
				rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
			}

			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = rd.readLine()) != null) {
				sb.append(line);
			}

			rd.close();
			conn.disconnect();
			
			String xml = sb.toString();
			//logger.debug(xml);
			
			
			// XML → 객체 변환
			JAXBContext context = JAXBContext.newInstance(WeatherMidTaResponseXml.class);
			Unmarshaller unmarshaller = context.createUnmarshaller();
			WeatherMidTaResponseXml response = (WeatherMidTaResponseXml) unmarshaller.unmarshal(new StringReader(xml));

			// 결과 출력
			//logger.debug("결과 코드: " + response.getHeader().getResultCode());
			//logger.debug("결과 메시지: " + response.getHeader().getResultMsg());
			
			String resultCode = response.getHeader().getResultCode();
			
			if("00".equals(resultCode)) {
				for (WeatherMidTaResponseXml.Body.Items.Item item : response.getBody().getItems().getItemList()) {
					if(null == item) continue;

					returnMap.put("midtaItem", item);
					//logger.debug("지역: " + item.getRegId());
					//logger.debug("4일 후 최저: " + item.getTaMin4() + " / 최고: " + item.getTaMax4());
					//logger.debug("5일 후 최저: " + item.getTaMin5() + " / 최고: " + item.getTaMax5());
					//logger.debug("6일 후 최저: " + item.getTaMin6() + " / 최고: " + item.getTaMax6());
					//logger.debug("7일 후 최저: " + item.getTaMin7() + " / 최고: " + item.getTaMax7());
					//logger.debug("8일 후 최저: " + item.getTaMin8() + " / 최고: " + item.getTaMax8());
					//logger.debug("9일 후 최저: " + item.getTaMin9() + " / 최고: " + item.getTaMax9());
					//logger.debug("10일 후 최저: " + item.getTaMin10() + " / 최고: " + item.getTaMax10());
					
					//logger.debug("--------------------------------");
				}
				
			} else {
				//logger.debug("resultCode 00 X : " + resultCode);
			}

			
			//logger.debug("--------------------------------");

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return returnMap;
	}
	
	
	/**
	 * 기상청 API 중기육상예보
	 * @작성일 : 2025. 6. 12
	 * @작성자 : ijy
	 */
	public Map<String, Object> getWeatherMidLandApi(String tmFc, String regId){
		Map<String, Object> returnMap = new HashMap<>();
		try {
			StringBuilder urlBuilder = new StringBuilder(weatherApiMidLandUrl);
			urlBuilder.append("?serviceKey=" + weatherApiEnKey);
			urlBuilder.append("&pageNo=1");
			urlBuilder.append("&numOfRows=100");
			urlBuilder.append("&dataType=XML");
			urlBuilder.append("&regId="+regId);
			urlBuilder.append("&tmFc="+tmFc);
			
			
			URL url = new URL(urlBuilder.toString());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-type", "application/json");

			//logger.debug("Response Code: " + conn.getResponseCode());

			BufferedReader rd;
			if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
				rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			} else {
				rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
			}

			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = rd.readLine()) != null) {
				sb.append(line);
			}

			rd.close();
			conn.disconnect();
			
			String xml = sb.toString();
			//logger.debug(xml);
			
			
			// XML → 객체 변환
			JAXBContext context = JAXBContext.newInstance(WeatherMidLandResponseXml.class);
			Unmarshaller unmarshaller = context.createUnmarshaller();
			WeatherMidLandResponseXml response = (WeatherMidLandResponseXml) unmarshaller.unmarshal(new StringReader(xml));

			// 결과 출력
			//logger.debug("결과 코드: " + response.getHeader().getResultCode());
			//logger.debug("결과 메시지: " + response.getHeader().getResultMsg());
			
			String resultCode = response.getHeader().getResultCode();
			
			if("00".equals(resultCode)) {
				for (WeatherMidLandResponseXml.Body.Items.Item item : response.getBody().getItems().getItem()) {
					returnMap.put("midlandItem", item);
					
					
					//logger.debug("지역: " + item.getRegId());
					//logger.debug("4일 후 날씨 오전: " + item.getWf4Am() + " / 오후: " + item.getWf4Pm());
					//logger.debug("5일 후 날씨 오전: " + item.getWf5Am() + " / 오후: " + item.getWf5Pm());
					//logger.debug("6일 후 날씨 오전: " + item.getWf6Am() + " / 오후: " + item.getWf6Pm());
					//logger.debug("7일 후 날씨 오전: " + item.getWf7Am() + " / 오후: " + item.getWf7Pm());
					//logger.debug("8일 후 날씨: " + item.getWf8());
					//logger.debug("9일 후 날씨: " + item.getWf9());
					//logger.debug("10일 후 날씨: " + item.getWf10());
					
					
					//logger.debug("4일 후 강수확률 오전: " + item.getRnSt4Am() + " / 오후: " + item.getRnSt4Pm());
					//logger.debug("5일 후 강수확률 오전: " + item.getRnSt5Am() + " / 오후: " + item.getRnSt5Pm());
					//logger.debug("6일 후 강수확률 오전: " + item.getRnSt6Am() + " / 오후: " + item.getRnSt6Pm());
					//logger.debug("7일 후 강수확률 오전: " + item.getRnSt7Am() + " / 오후: " + item.getRnSt7Pm());
					//logger.debug("8일 후 강수확률: " + item.getRnSt8());
					//logger.debug("9일 후 강수확률: " + item.getRnSt9());
					//logger.debug("10일 후 강수확률: " + item.getRnSt10());
					
					//logger.debug("--------------------------------");
				}
				
			} else {
				//logger.debug("resultCode 00 X : " + resultCode);
			}

			
			//logger.debug("--------------------------------");

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return returnMap;
	}
	
	
	/**
	 * 주소로 중기예보구역코드 조회.
	 * 기상청에서 제공한 구역 코드는 광주, 고성 등 동일 지명이 존재하고 전북자치도, 충청남도 등으로 제공되는데
	 * 크나우프에서 사용하는 실제 주소는 광주 북구 무슨대로, 광주시 남구 무슨동, 광주광역시, 전북 순천 무슨리, 전라북도 순천 무슨리
	 * 경남 고성, 경상남도 고성, 강원도 고성, 강원 고성, 대구 북구 고성동 등 과 같은 다양한 형태로 저장되어 있음.
	 * 단순 주소로만 조회하면 오작동할 확률이 높아 구역코드를 경남 고성, 경상남도 고성, 강원 고성, 강원도 고성 강원특별자치도 고성 등 동일 코드, 다양한 명칭으로 적재하고 매칭 로직 추가.
	 * @작성일 : 2025. 6. 13
	 * @작성자 : ijy
	 */
	public String getWeatherAreaCd (String addr, String type) {
		Map<String, Object> svcMap = new HashMap<>();
		svcMap.put("addr", addr);
		
		//주소 정보로 예보구역코드를 조회, 더 일치하는 구역코드로 매핑.
		List<WeatherDto> areaList = new ArrayList<WeatherDto>();
		if("ta".equals(type)) {
			areaList = weatherDao.getWeatherMidTaAreaList(svcMap); //기온
		} else {
			//중기육상예보구역코드는 서울, 인천, 경기, 경남, 경북, 강원 등 광역자치단체 구분
			//다른 지역은 문제 없으나 강원 지역만 강원 영동,영서로 구분됨.
			//강원은 광역이 아닌 춘천, 원주, 홍천, 강릉, 동해, 속초 등 기초자치단체까지 적재하여 영동, 영서 구분
			areaList = weatherDao.getWeatherMidLandAreaList(svcMap); //육상
		}
		
		//고성, 광주 등 동일 지명이 포함된 주소일 경우 오작동 예방 차원, 더 일치하는 구역코드로 매칭.
		String areaCd = "";
		String areaNm = "";
		String normalizedAddress = addr.replace("도 ", "도").replaceAll("\\s+", "");
		Optional<WeatherDto> bestMatch = areaList.stream()
		    .filter(dto -> normalizedAddress.contains(dto.getAREA_NM().replaceAll("\\s+", "")))
		    .max(Comparator.comparingInt(dto -> dto.getAREA_NM().replaceAll("\\s+", "").length()));

		if (bestMatch.isPresent()) {
		    areaCd = bestMatch.get().getAREA_CD();
		    areaNm = bestMatch.get().getAREA_NM();
		    //logger.debug(type + "] 최장 일치 코드: " + areaCd + " / NM: " + areaNm + " / addr:" + addr);
		} else {
		    //logger.debug(type + "] 일치하는 코드 없음 / " + addr);
		}

		return areaCd;
	}
	
	
	public static List<Map<String, Object>> summarizeMidForecastOld( Map<String, Object> tItem, Map<String, Object> lItem ) {
		
        WeatherMidTaResponseXml.Body.Items.Item taItem     = (WeatherMidTaResponseXml.Body.Items.Item) tItem.get("taItem");
        WeatherMidLandResponseXml.Body.Items.Item landItem = (WeatherMidLandResponseXml.Body.Items.Item) lItem.get("landItem");

        
	    List<Map<String, Object>> list = new ArrayList<>();
	    LocalDate today = LocalDate.now();
	    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	    for (int i = 4; i <= 10; i++) {
	        Map<String, Object> map = new HashMap<>();

	        LocalDate targetDate = today.plusDays(i);
	        DayOfWeek dayOfWeek = targetDate.getDayOfWeek();

	        map.put("date", targetDate.format(dateFormatter));
	        map.put("dayOfWeek", getKoreanDayOfWeek(dayOfWeek));

	        map.put("minTemp", getField(taItem, "taMin" + i));
	        map.put("maxTemp", getField(taItem, "taMax" + i));

	        if (i <= 7) {
	            map.put("amWeather", getField(landItem, "wf" + i + "Am"));
	            map.put("pmWeather", getField(landItem, "wf" + i + "Pm"));
	            map.put("amPop", getField(landItem, "rnSt" + i + "Am"));
	            map.put("pmPop", getField(landItem, "rnSt" + i + "Pm"));
	        } else {
	            String weather = getField(landItem, "wf" + i);
	            String pop = getField(landItem, "rnSt" + i);
	            map.put("amWeather", weather);
	            map.put("pmWeather", weather);
	            map.put("amPop", pop);
	            map.put("pmPop", pop);
	        }

	        list.add(map);
	    }

	    return list;
	}
	

	/**
	 * 중기 예보 데이터를 요약하여 날짜별 날씨 정보를 리스트로 반환합니다.
	 *
	 * @param tItem 기온 정보가 포함된 맵 (key: "taItem", value: WeatherMidTaResponseXml.Body.Items.Item)
	 * @param lItem 육상 예보 정보가 포함된 맵 (key: "landItem", value: WeatherMidLandResponseXml.Body.Items.Item)
	 * @return 날짜, 요일, 기온, 날씨, 강수확률 정보를 포함하는 리스트
	 */
	public static List<Map<String, Object>> summarizeMidForecast( Map<String, Object> tItem, Map<String, Object> lItem ) {
		
	    // Step 1: 입력 맵에서 기온 및 육상 예보 객체 추출
        WeatherMidTaResponseXml.Body.Items.Item taItem     = (WeatherMidTaResponseXml.Body.Items.Item) tItem.get("midtaItem");
        WeatherMidLandResponseXml.Body.Items.Item landItem = (WeatherMidLandResponseXml.Body.Items.Item) lItem.get("midlandItem");
        
        
        // 결과를 저장할 리스트
	    List<Map<String, Object>> list = new ArrayList<>();
	    LocalDate today = LocalDate.now();
	    DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	    // Step 2: 4일 후부터 10일 후까지 루프
	    for (int i = 4; i <= 7; i++) {
	        Map<String, Object> map = new HashMap<>();

	        // Step 3: 날짜 및 요일 계산
	        LocalDate targetDate = today.plusDays(i);
	        DayOfWeek dayOfWeek = targetDate.getDayOfWeek();

	        map.put("date", targetDate.format(dateFormatter));
	        map.put("dayOfWeek", getKoreanDayOfWeek(dayOfWeek));

	        // Step 4: 기온 정보 설정
	        map.put("minTemp", getField(taItem, "taMin" + i));
	        map.put("maxTemp", getField(taItem, "taMax" + i));

	        // Step 5: 오전/오후 날씨 및 강수확률 설정 (7일까지는 AM/PM, 이후는 단일 예보 복제)
            map.put("amWeather", getField(landItem, "wf" + i + "Am"));
            map.put("pmWeather", getField(landItem, "wf" + i + "Pm"));
            map.put("amPop", getField(landItem, "rnSt" + i + "Am"));
            map.put("pmPop", getField(landItem, "rnSt" + i + "Pm"));

	        // Step 6: 결과 리스트에 추가
	        list.add(map);
	    }

	    return list;
	}
	

	
	private static String getField(Object obj, String fieldName) {
	    try {
	        Field field = obj.getClass().getDeclaredField(fieldName);
	        field.setAccessible(true);
	        return (String) field.get(obj);
	    } catch (Exception e) {
	        return null;
	    }
	}
	
	private static String getKoreanDayOfWeek(DayOfWeek dayOfWeek) {
	    switch (dayOfWeek) {
	        case MONDAY:    return "월";
	        case TUESDAY:   return "화";
	        case WEDNESDAY: return "수";
	        case THURSDAY:  return "목";
	        case FRIDAY:    return "금";
	        case SATURDAY:  return "토";
	        case SUNDAY:    return "일";
	        default:        return "";
	    }
	}


}