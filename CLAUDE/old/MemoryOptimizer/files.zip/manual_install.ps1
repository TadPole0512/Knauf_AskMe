# Memory Optimizer - Manual Installation Script
# Run as Administrator in PowerShell

Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host "         Memory Optimizer v2.0 - Manual Installation" -ForegroundColor Cyan
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host ""

# Check admin rights
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "[ERROR] Administrator privileges required!" -ForegroundColor Red
    Write-Host "Right-click PowerShell and select 'Run as administrator'" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# Installation paths
$INSTALL_DIR = "C:\Tools\MemoryOptimizer_CLAUDE"
$DATA_DIR = "C:\ProgramData\MemoryOptimizer_CLAUDE"

Write-Host "[1/6] Creating directories..." -ForegroundColor Green
New-Item -ItemType Directory -Path "$INSTALL_DIR\config" -Force | Out-Null
New-Item -ItemType Directory -Path "$INSTALL_DIR\docs" -Force | Out-Null
New-Item -ItemType Directory -Path "$INSTALL_DIR\scripts" -Force | Out-Null
New-Item -ItemType Directory -Path "$DATA_DIR\logs" -Force | Out-Null
New-Item -ItemType Directory -Path "$DATA_DIR\reports" -Force | Out-Null
New-Item -ItemType Directory -Path "$DATA_DIR\backup" -Force | Out-Null
Write-Host "  OK Directories created" -ForegroundColor White

Write-Host ""
Write-Host "[2/6] Copy files manually..." -ForegroundColor Green
Write-Host "  Please copy the following files:" -ForegroundColor Yellow
Write-Host "    - scripts/*.ps1 -> $INSTALL_DIR\scripts\" -ForegroundColor Gray
Write-Host "    - scripts/*.py -> $INSTALL_DIR\scripts\" -ForegroundColor Gray
Write-Host "    - scripts/*.bat -> $INSTALL_DIR\scripts\" -ForegroundColor Gray
Write-Host "    - config/*.json -> $INSTALL_DIR\config\" -ForegroundColor Gray
Write-Host "    - docs/*.md -> $INSTALL_DIR\docs\" -ForegroundColor Gray
Write-Host ""
Read-Host "Press Enter after copying files"

Write-Host ""
Write-Host "[3/6] Checking Python..." -ForegroundColor Green
try {
    $pythonVersion = python --version 2>&1
    Write-Host "  OK Python detected: $pythonVersion" -ForegroundColor White
    
    Write-Host "  Installing psutil..." -ForegroundColor Gray
    python -m pip install psutil --break-system-packages --quiet 2>&1 | Out-Null
    Write-Host "  OK psutil installed" -ForegroundColor White
}
catch {
    Write-Host "  ! Python not installed" -ForegroundColor Yellow
    Write-Host "    Download: https://www.python.org/downloads/" -ForegroundColor Gray
}

Write-Host ""
Write-Host "[4/6] Creating desktop shortcut..." -ForegroundColor Green
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\MemoryClean.lnk")
$Shortcut.TargetPath = "powershell.exe"
$Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$INSTALL_DIR\scripts\QuickMemoryClean.ps1`""
$Shortcut.WindowStyle = 1
$Shortcut.IconLocation = "C:\Windows\System32\shell32.dll,242"
$Shortcut.Save()
Write-Host "  OK Desktop shortcut created" -ForegroundColor White

Write-Host ""
Write-Host "[5/6] Creating Start Menu shortcuts..." -ForegroundColor Green
$StartMenu = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Memory Optimizer"
New-Item -ItemType Directory -Path $StartMenu -Force | Out-Null

$Shortcut = $WshShell.CreateShortcut("$StartMenu\MemoryClean.lnk")
$Shortcut.TargetPath = "powershell.exe"
$Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$INSTALL_DIR\scripts\QuickMemoryClean.ps1`""
$Shortcut.WindowStyle = 1
$Shortcut.Save()

$Shortcut = $WshShell.CreateShortcut("$StartMenu\Restore.lnk")
$Shortcut.TargetPath = "$INSTALL_DIR\scripts\restore.bat"
$Shortcut.WindowStyle = 1
$Shortcut.Save()
Write-Host "  OK Start Menu shortcuts created" -ForegroundColor White

Write-Host ""
Write-Host "[6/6] Adding to PATH..." -ForegroundColor Green
try {
    $currentPath = [Environment]::GetEnvironmentVariable("PATH", "Machine")
    if ($currentPath -notlike "*$INSTALL_DIR\scripts*") {
        [Environment]::SetEnvironmentVariable("PATH", "$currentPath;$INSTALL_DIR\scripts", "Machine")
        Write-Host "  OK Added to PATH" -ForegroundColor White
    }
    else {
        Write-Host "  OK Already in PATH" -ForegroundColor White
    }
}
catch {
    Write-Host "  ! Failed to add to PATH" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host "                    Installation Complete!" -ForegroundColor Cyan
Write-Host "=====================================================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "Quick Start:" -ForegroundColor Yellow
Write-Host "  1. Desktop shortcut: MemoryClean" -ForegroundColor White
Write-Host "  2. PowerShell: cd $INSTALL_DIR\scripts" -ForegroundColor White
Write-Host "                 .\QuickMemoryClean.ps1" -ForegroundColor White
Write-Host ""

$choice = Read-Host "Run memory cleanup now? (Y/N)"
if ($choice -eq "Y" -or $choice -eq "y") {
    Write-Host ""
    Write-Host "Running memory cleanup..." -ForegroundColor Green
    & "$INSTALL_DIR\scripts\QuickMemoryClean.ps1"
}

Write-Host ""
Write-Host "Installation completed. Press Enter to exit..." -ForegroundColor Gray
Read-Host
